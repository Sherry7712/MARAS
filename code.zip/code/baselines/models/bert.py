import os
import torch
import tqdm
import torch.nn as nn
import numpy as np
from .layers import *
from sklearn.metrics import *
from transformers import BertModel
from utils.utils import data2gpu, Averager, metrics, Recorder

class BertFNModel(torch.nn.Module):
    def __init__(self, emb_dim, mlp_dims, bert_emb, dropout):
        super(BertFNModel, self).__init__()
        self.bert = BertModel.from_pretrained(bert_emb).requires_grad_(False)

        # for name, param in self.bert.named_parameters():
        #     param.requires_grad = True
        #     if name.startswith("encoder.layer.11") \
        #             or name.startswith('encoder.layer.10') \
        #             or name.startswith('encoder.layer.9') \
        #             or name.startswith('encoder.layer.8') \
        #             or name.startswith('encoder.layer.7'):# \
        #             or name.startswith('encoder.layer.6')\
        #             or name.startswith('encoder.layer.5') \
        #             or name.startswith('encoder.layer.4')\
        #             or name.startswith('encoder.layer.3'):
        #         param.requires_grad = True
        #     else:
        #         param.requires_grad = False
        self.mlp = MLP(emb_dim, mlp_dims, dropout)
        self.attention = MaskAttention(emb_dim)
    
    def forward(self, inputs, masks, **kwargs):
        # bert_feature = self.bert(inputs, attention_mask = masks).last_hidden_state[:, 0]
        bert_feature = self.bert(inputs, attention_mask = masks).last_hidden_state
        bert_feature, _ = self.attention(bert_feature, masks)
        output = self.mlp(bert_feature)
        return torch.sigmoid(output.squeeze(1))


class Trainer():
    def __init__(self,
                 emb_dim,
                 mlp_dims,
                 bert_emb,
                 use_cuda,
                 lr,
                 dropout,
                 train_loader,
                 val_loader,
                 test_loader,
                 category_dict,
                 weight_decay,
                 early_stop = 5,
                 epoches = 100
                 ):
        self.lr = lr
        self.weight_decay = weight_decay
        self.use_cuda = use_cuda
        self.train_loader = train_loader
        self.test_loader = test_loader
        self.val_loader = val_loader
        self.early_stop = early_stop
        self.epoches = epoches
        self.category_dict = category_dict
        self.model = BertFNModel(emb_dim, mlp_dims, bert_emb, dropout)
        if use_cuda:
            self.model = self.model.cuda()
        

    def train(self):
        loss_fn = torch.nn.BCELoss()
        optimizer = torch.optim.Adam(params=self.model.parameters(), lr=self.lr, weight_decay=self.weight_decay)
        recorder = Recorder(self.early_stop)
        for epoch in range(self.epoches):
            self.model.train()
            train_data_iter = tqdm.tqdm(self.train_loader)
            avg_loss = Averager()

            for step_n, batch in enumerate(train_data_iter):
                batch_data = data2gpu(batch, self.use_cuda)
                label = batch_data['label']

                optimizer.zero_grad()
                pred = self.model(**batch_data)
                loss = loss_fn(pred, label.float())
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                avg_loss.add(loss.item())
            print('Training Epoch {}; Loss {}; '.format(epoch + 1, avg_loss.item()))

            results = self.test(self.val_loader)
            mark = recorder.add(results)
            if mark == 'save':
                 torch.save(self.model.state_dict(),
                    'parameter_bert.pkl')
            elif mark == 'esc':
                break
            else:
                continue
        self.model.load_state_dict(torch.load('parameter_bert.pkl'))
        results = self.test(self.test_loader)
        print(results)

    def test(self, dataloader):
        pred = []
        label = []
        category = []
        self.model.eval()
        data_iter = tqdm.tqdm(dataloader)
        for step_n, batch in enumerate(data_iter):
            with torch.no_grad():
                batch_data = data2gpu(batch, self.use_cuda)
                batch_label = batch_data['label']
                batch_category = batch_data['category']
                batch_pred = self.model(**batch_data)

                label.extend(batch_label.detach().cpu().numpy().tolist())
                pred.extend(batch_pred.detach().cpu().numpy().tolist())
                category.extend(batch_category.detach().cpu().numpy().tolist())
        
        return metrics(label, pred, category, self.category_dict)
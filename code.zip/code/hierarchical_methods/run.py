from gensim.models.keyedvectors import Vocab
from utils.dataloader import w2v_data, test_w2v_data
import torch
import tqdm
import pickle
from utils.utils import Averager
from utils.dataloader import bert_data
from models.bilstm import Trainer as BiLSTMTrainer
from models.han import Trainer as HANTrainer
from models.nhfm import Trainer as NHFMTrainer
from models.mrtaghlstm import Trainer as MyTrainer1
from models.mrtaghlstm1 import Trainer as MyTrainer2

class Run():
    def __init__(self,
                 config
                 ):
        self.use_cuda = config['use_cuda']
        self.model_name = config['model_name']
        self.batchsize = config['batchsize']
        self.emb_dim = config['emb_dim']
        self.weight_decay = config['weight_decay']
        self.lr = config['lr']
        self.epoch = config['epoch']
        self.emb_type = config['emb_type']
        self.num_ng = config['num_ng']
        self.max_len = config['max_len']
        self.max_snum_user = config['max_snum_user']
        self.max_snum_item = config['max_snum_item']
        self.num_workers = config['num_workers']
        self.vocab_file = config['vocab_file']
        self.early_stop = config['early_stop']
        self.bert_emb = config['bert_emb']
        self.root_path = config['root_path']
        self.mlp_dims = config['model']['mlp']['dims']
        self.dropout = config['model']['mlp']['dropout']


        self.train_user_path = self.root_path + 'train_user.pkl'
        self.test_user_path = self.root_path + 'test_user.pkl'
        self.train_rating_path = self.root_path + 'train_rating.pkl'
        self.test_rating_path = self.root_path + 'test_rating.pkl'
        self.item_path = self.root_path + 'item.pkl'
        # self.train_user_path = self.root_path + 'train_user.csv'
        # self.test_user_path = self.root_path + 'test_user.csv'
        # self.train_rating_path = self.root_path + 'train_rating.csv'
        # self.test_rating_path = self.root_path + 'test_rating.csv'
        # self.item_path = self.root_path + 'item.csv'

    def get_dataloader(self):
        if self.emb_type == 'bert':
            loader = bert_data(max_len = self.max_len, batch_size = self.batchsize, vocab_file = self.vocab_file,
                        num_workers=self.num_workers)
        elif self.emb_type == 'w2v':
            loader = w2v_data(max_len=self.max_len, vocab_file=self.vocab_file, emb_dim = self.emb_dim,
                    batch_size=self.batchsize, num_workers= self.num_workers, num_ng = self.num_ng, max_snum_item=self.max_snum_item
                    , max_snum_user=self.max_snum_user)
            loader2 = test_w2v_data(max_len=self.max_len, vocab_file=self.vocab_file, emb_dim = self.emb_dim,
                    batch_size=self.batchsize, num_workers= self.num_workers, num_ng = self.num_ng, max_snum_item=self.max_snum_item
                    , max_snum_user=self.max_snum_user)
        train_loader = loader.load_data(self.item_path, self.train_user_path, self.train_rating_path, True)
        test_loader1 = loader.load_data(self.item_path, self.test_user_path, self.test_rating_path, False)
        test_loader2 = loader2.load_data(self.item_path, self.test_user_path, self.test_rating_path, False)
        return train_loader, test_loader1, test_loader2

    def main(self):
        train_loader, test_loader1, test_loader2 = self.get_dataloader()
        if self.model_name == 'bilstm':
            trainer = BiLSTMTrainer(emb_dim = self.emb_dim, mlp_dims = self.mlp_dims, bert_emb = self.bert_emb, emb_type = self.emb_type,
                use_cuda = self.use_cuda, lr = self.lr, train_loader = train_loader, dropout = self.dropout, weight_decay = self.weight_decay,
                test_loader1 = test_loader1, test_loader2 = test_loader2, num_layers = 1, early_stop = self.early_stop, max_snum_item=self.max_snum_item
                    , max_snum_user=self.max_snum_user)
        elif self.model_name == 'han':
            trainer = HANTrainer(emb_dim = self.emb_dim, mlp_dims = self.mlp_dims, bert_emb = self.bert_emb, emb_type = self.emb_type,
                use_cuda = self.use_cuda, lr = self.lr, train_loader = train_loader, dropout = self.dropout, weight_decay = self.weight_decay,
                test_loader1 = test_loader1, test_loader2 = test_loader2, num_layers = 1, early_stop = self.early_stop, max_snum_item=self.max_snum_item
                    , max_snum_user=self.max_snum_user)
        elif self.model_name == 'nhfm':
            trainer = NHFMTrainer(emb_dim = self.emb_dim, mlp_dims = self.mlp_dims, bert_emb = self.bert_emb, emb_type = self.emb_type,
                use_cuda = self.use_cuda, lr = self.lr, train_loader = train_loader, dropout = self.dropout, weight_decay = self.weight_decay,
                test_loader1 = test_loader1, test_loader2 = test_loader2, num_layers = 1, early_stop = self.early_stop, max_snum_item=self.max_snum_item
                    , max_snum_user=self.max_snum_user)
        elif self.model_name == 'my1':
            trainer = MyTrainer1(emb_dim = self.emb_dim, mlp_dims = self.mlp_dims, bert_emb = self.bert_emb, emb_type = self.emb_type,
                use_cuda = self.use_cuda, lr = self.lr, train_loader = train_loader, dropout = self.dropout, weight_decay = self.weight_decay,
                test_loader1 = test_loader1, test_loader2 = test_loader2, num_layers = 1, early_stop = self.early_stop, max_snum_item=self.max_snum_item
                    , max_snum_user=self.max_snum_user)
        elif self.model_name == 'my2':
            trainer = MyTrainer2(emb_dim = self.emb_dim, mlp_dims = self.mlp_dims, bert_emb = self.bert_emb, emb_type = self.emb_type,
                use_cuda = self.use_cuda, lr = self.lr, train_loader = train_loader, dropout = self.dropout, weight_decay = self.weight_decay,
                test_loader1 = test_loader1, test_loader2 = test_loader2, num_layers = 1, early_stop = self.early_stop, max_snum_item=self.max_snum_item
                    , max_snum_user=self.max_snum_user)
        trainer.train()
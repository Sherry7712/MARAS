import os
import torch
import tqdm
import torch.nn as nn
import numpy as np
from .layers import *
from sklearn.metrics import *
from transformers import BertModel
from utils.utils import data2gpu, Averager, metrics, Recorder

class HANModel(torch.nn.Module):
    def __init__(self, emb_dim, num_layers, mlp_dims, bert_emb, dropout, emb_type, max_snum_item, max_snum_user):
        super(HANModel, self).__init__()

        self.emb_type = emb_type
        self.item_max_sentence_num = max_snum_item
        self.user_max_sentence_num = max_snum_user
        if emb_type == 'bert':
            self.bert = BertModel.from_pretrained(bert_emb).requires_grad_(False)
        
        self.fc1 = nn.Linear(emb_dim, emb_dim)
        self.fc2 = nn.Linear(emb_dim, emb_dim)

        self.attention = MaskAttention(emb_dim)
        self.attention2 = MaskAttention(emb_dim)
        self.mlp = MLP(emb_dim, mlp_dims, dropout)
    
    def forward(self, **kwargs):
        if self.emb_type == 'bert':
            feature = self.bert(inputs, attention_mask = masks).last_hidden_state
        elif self.emb_type == 'w2v':
            item_desc = kwargs['item_desc']
            user_desc = kwargs['user_desc']
            item_desc_mask = kwargs['item_desc_mask']
            user_desc_mask = kwargs['user_desc_mask']
        item_desc = item_desc.view(-1, item_desc.size(2), item_desc.size(3))
        user_desc = user_desc.view(-1, user_desc.size(2), user_desc.size(3))
        item_desc_mask = item_desc_mask.view(-1, item_desc_mask.size(2))
        user_desc_mask = user_desc_mask.view(-1, user_desc_mask.size(2))


        item_desc = self.fc1(item_desc)
        item_desc, _ = self.attention(item_desc, item_desc_mask)

        user_desc = self.fc1(user_desc)
        user_desc, _ = self.attention(user_desc, user_desc_mask)

        item_desc = item_desc.view(-1, self.item_max_sentence_num, item_desc.size(1))
        user_desc = user_desc.view(-1, self.user_max_sentence_num, user_desc.size(1))

        item_desc = self.fc2(item_desc)
        item_desc, _ = self.attention2(item_desc, kwargs['item_sentence_mask'])

        user_desc = self.fc2(user_desc)
        user_desc, _ = self.attention2(user_desc, kwargs['user_sentence_mask'])

        x = torch.sum(user_desc * item_desc, dim=1)
        return torch.sigmoid(x)


class Trainer():
    def __init__(self,
                 emb_dim,
                 mlp_dims,
                 bert_emb,
                 use_cuda,
                 lr,
                 dropout,
                 num_layers, 
                 train_loader,
                 test_loader1,
                 test_loader2,
                 weight_decay,
                 emb_type = 'w2v',
                 early_stop = 5,
                 epoches = 100,
                 max_snum_item=5, max_snum_user=5
                 ):
        self.lr = lr
        self.weight_decay = weight_decay
        self.use_cuda = use_cuda
        self.train_loader = train_loader
        self.test_loader1 = test_loader1
        self.test_loader2 = test_loader2
        self.early_stop = early_stop
        self.epoches = epoches
        self.model = HANModel(emb_dim, num_layers, mlp_dims, bert_emb, dropout, emb_type, max_snum_item, max_snum_user)
        if use_cuda:
            self.model = self.model.cuda()
        

    def train(self):

        loss_fn = torch.nn.BCELoss()
        optimizer = torch.optim.Adam(params=self.model.parameters(), lr=self.lr, weight_decay=self.weight_decay)
        recorder = Recorder(self.early_stop)
        for epoch in range(self.epoches):
            self.model.train()
            iter_target = iter(self.train_loader)
            train_data_iter = tqdm.tqdm(self.train_loader)
            avg_loss = Averager()

            for step_n, batch in enumerate(train_data_iter):
                batch_data = data2gpu(batch, self.use_cuda)
                label = batch_data['labels']

                optimizer.zero_grad()
                pred = self.model(**batch_data)
                loss = loss_fn(pred, label.float())
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                avg_loss.add(loss.item())
            print('Training Epoch {}; Loss {}; '.format(epoch + 1, avg_loss.item()))

            results = self.testauc(self.test_loader1)
            mark = recorder.add(results)
            if mark == 'save':
                 torch.save(self.model.state_dict(),
                    'parameter_han.pkl')
            elif mark == 'esc':
                break
            else:
                continue
        self.model.load_state_dict(torch.load('parameter_han.pkl'))
        results = self.test(self.test_loader2)
        print(results)

    def testauc(self, dataloader):
        pred = []
        label = []
        self.model.eval()
        data_iter = tqdm.tqdm(dataloader)
        for step_n, batch in enumerate(data_iter):
            with torch.no_grad():
                batch_data = data2gpu(batch, self.use_cuda)
                batch_label = batch_data['labels']
                batch_pred = self.model(**batch_data)

                label.extend(batch_label.detach().cpu().numpy().tolist())
                pred.extend(batch_pred.detach().cpu().numpy().tolist())
        
        return {'metric': roc_auc_score(label, pred).round(4).tolist()}

    def test(self, dataloader):
        pred = []
        label = []
        self.model.eval()
        data_iter = tqdm.tqdm(dataloader)
        recall = [0] * 10
        precision = [0] * 10
        f1 = [0] * 10
        num = 0
        for step_n, batch in enumerate(data_iter):
            with torch.no_grad():
                batch_data = data2gpu(batch, self.use_cuda)
                batch_label = batch_data['labels']
                batch_pred = self.model(**batch_data)
                num += 1

                for topk in range(1, 11):
                    targets = np.array(batch_label.cpu())
                    predicts = np.array(batch_pred.cpu())
                    length = targets.shape[0]
                    cr_index = set(np.argwhere(targets == 1).reshape(-1).tolist())
                    rec_index = set(np.argpartition(predicts, -min(topk, length))[-min(topk, length):].tolist())
                    tmp_precision = len(cr_index & rec_index) / len(rec_index)
                    tmp_recall = len(cr_index & rec_index) / len(cr_index)
                    precision[topk - 1] += tmp_precision
                    recall[topk - 1] += tmp_recall
                    sum_pr = tmp_precision + tmp_recall
                    if sum_pr == 0:
                        sum_pr = 100
                    f1[topk - 1] += (2 * tmp_precision * tmp_recall) / sum_pr

                label.extend(batch_label.detach().cpu().numpy().tolist())
                pred.extend(batch_pred.detach().cpu().numpy().tolist())
        for i in range(10):
            recall[i] = recall[i] / num
            precision[i] = precision[i] / num
            f1[i] = f1[i] / num
        
        return {'metric': roc_auc_score(label, pred).round(4).tolist(), 'recall': recall, 'precision': precision, 'f1': f1}
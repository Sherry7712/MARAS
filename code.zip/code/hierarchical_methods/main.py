import os
import argparse
parser = argparse.ArgumentParser()
parser.add_argument('--model_name', default='nhfm')#bilstm han my1 my2
parser.add_argument('--epoch', type=int, default=50)
parser.add_argument('--max_len', type=int, default=20)
parser.add_argument('--max_snum_item', type=int, default=4)
parser.add_argument('--max_snum_user', type=int, default=2)
parser.add_argument('--num_workers', type=int, default=2)
parser.add_argument('--num_ng', type=int, default=4)
parser.add_argument('--early_stop', type=int, default=3)
parser.add_argument('--bert_vocab_file', default='/data/lisk/zhuyc/CrossDomainFNews/pretrain_model/chinese_roberta_wwm_base_ext_pytorch/vocab.txt')
parser.add_argument('--root_path', default='/home/lisk/zhuyc/gbl/hierarchical_methods/data/')
parser.add_argument('--bert_emb', default='/data/lisk/zhuyc/CrossDomainFNews/pretrain_model/chinese_roberta_wwm_base_ext_pytorch')
parser.add_argument('--batchsize', type=int, default=128)
parser.add_argument('--seed', type=int, default=2020)
parser.add_argument('--gpu', default='0')
parser.add_argument('--bert_emb_dim', type=int, default=768)
parser.add_argument('--w2v_emb_dim', type=int, default=300)
parser.add_argument('--lr', type=float, default=0.001)
parser.add_argument('--emb_type', default='w2v')#bert w2v  (textcnn  bigru   eann   mmoe   mose)
parser.add_argument('--w2v_vocab_file', default='/data/lisk/CRSLab-add-profile-analyse-study/data/embedding/en/cc.en.300.bin')

args = parser.parse_args()
os.environ["CUDA_VISIBLE_DEVICES"] = args.gpu

from run import Run
import torch
import numpy as np
import random

seed = args.seed
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)

if args.emb_type == 'bert':
    emb_dim = args.bert_emb_dim
    vocab_file = args.bert_vocab_file
elif args.emb_type == 'w2v':
    emb_dim = args.w2v_emb_dim
    vocab_file = args.w2v_vocab_file

print('lr: {}; model name: {}; batchsize: {}; epoch: {}; gpu: {}; emb_dim: {}'.format(args.lr, args.model_name, args.batchsize, args.epoch, args.gpu, emb_dim))


config = {
        'use_cuda': True,
        'batchsize': args.batchsize,
        'max_len': args.max_len,
        'max_snum_user': args.max_snum_user,
        'max_snum_item': args.max_snum_item,
        'early_stop': args.early_stop,
        'num_workers': args.num_workers,
        'vocab_file': vocab_file,
        'emb_type': args.emb_type,
        'bert_emb': args.bert_emb,
        'num_ng': args.num_ng,
        'root_path': args.root_path,
        'weight_decay': 0,
        'model':
            {
            'mlp': {'dims': (64, 64), 'dropout': 0.2}
            },
        'emb_dim': emb_dim,
        'lr': args.lr,
        'epoch': args.epoch,
        'model_name': args.model_name
        }

if __name__ == '__main__':
    Run(config = config
        ).main()
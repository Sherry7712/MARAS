import torch
import random
import pandas as pd
import tqdm
import numpy as np
import re
import jieba
import fasttext
from transformers import BertTokenizer
from torch.utils.data import TensorDataset, DataLoader
from gensim.models.keyedvectors import KeyedVectors, Vocab
import nltk

def df_filter(df_data):
    df_data = df_data[df_data['category'] != '无法确定']
    return df_data

class MashupSampler():

    def __init__(self, mashup_name):
        self.mashup_name = mashup_name
        self.m_ind = {}

    def __len__(self):
        return len(self.mashup_name)

    def __iter__(self):
        for name in self.mashup_name:
            ind = np.array([i for i, x in enumerate(self.mashup_name) if x == name]).tolist()
            #ind = torch.from_numpy(ind)
            yield ind

def word2input(texts, vocab_file, max_len):
    tokenizer = BertTokenizer(vocab_file=vocab_file)
    token_ids = []
    for i, text in enumerate(texts):
        token_ids.append(
            tokenizer.encode(text, max_length=max_len, add_special_tokens=True, padding='max_length',
                             truncation=True))
    token_ids = torch.tensor(token_ids)
    masks = torch.zeros(token_ids.shape)
    mask_token_id = tokenizer.pad_token_id
    for i, tokens in enumerate(token_ids):
        masks[i] = (tokens != mask_token_id)
    return token_ids, masks

class bert_data():
    def __init__(self, max_len, batch_size, vocab_file, category_dict, num_workers=2):
        self.max_len = max_len
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.vocab_file = vocab_file
        self.category_dict = category_dict

    def load_data(self, path, shuffle):
        self.data = df_filter(pd.read_csv(path))
        content = self.data['content'].to_numpy()
        label = torch.tensor(self.data['label'].to_numpy())
        category = torch.tensor(self.data['category'].apply(lambda c: self.category_dict[c]).to_numpy())
        token_ids, masks = word2input(content, self.vocab_file, self.max_len)
        dataset = TensorDataset(token_ids,
                                masks,
                                label,
                                category
                                )
        dataloader = DataLoader(
            dataset=dataset,
            batch_size=self.batch_size,
            num_workers=self.num_workers,
            pin_memory=True,
            shuffle=shuffle
        )
        return dataloader

class GBLdataset(torch.utils.data.Dataset):

    def __init__(self, item_path, user_path, rating_path, num_ng, max_len, emb_dim, vocab_file):
        self.data = pd.read_csv(rating_path)
        self.item = pd.read_csv(item_path)
        self.user = pd.read_csv(user_path)
        self.num_ng = num_ng
        self.itemid_set = set(self.item.APIName)
        self.w2v_model = fasttext.load_model(vocab_file)#KeyedVectors.load_word2vec_format(vocab_file, binary=True, unicode_errors='ignore')

        self.max_len = max_len
        self.emb_dim = emb_dim

    def tokenization(self, content):
        tokens = []
        for c in content:
            cut_c = nltk.word_tokenize(c)
            words = [word for word in cut_c]
            tokens.append(words)
        return tokens

    def get_mask(self, tokens, max_len):
        masks = []
        for token in tokens:
            if(len(token)< max_len):
                masks.append([1] * len(token) + [0] * (max_len - len(token)))
            else:
                masks.append([1] * max_len)
        
        return torch.tensor(masks)
    
    def encode(self, token_ids, max_len):
        # self.w2v_model = KeyedVectors.load('./pretrained/w2v/Tencent_AILab_Chinese_self.w2v_model.kv')
        
        #self.w2v_model = KeyedVectors.load(self.vocab_file)
        embedding = []
        for token_id in token_ids:
            words = [w for w in token_id[: max_len]]
            words_vec = []
            for word in words:
                words_vec.append(self.w2v_model[word] if word in self.w2v_model else np.zeros([self.emb_dim]))
            for i in range(len(words_vec), max_len):
                words_vec.append(np.zeros([self.emb_dim]))
            embedding.append(words_vec)
        return torch.tensor(np.array(embedding, dtype = np.float32))

    def get_emb(self, content, max_len):
        token_ids = self.tokenization(content)
        masks = self.get_mask(token_ids, max_len)
        emb_content = self.encode(token_ids, max_len)
        return emb_content, masks

    def __len__(self):
        return self.data.shape[0]

    def __getitem__(self, index):
        item_name = self.data.iloc[index].APIName
        user_name = self.data.iloc[index].MashupName
        user_line = self.user.loc[self.user["MashupName"] == user_name]
        item_line = self.item.loc[self.item["APIName"] == item_name]
        user_desc = user_line['desc']
        user_tags = user_line['tags']
        item_desc = item_line['desc']
        item_tags = item_line['tags']
        user_desc_emb, user_desc_mask = self.get_emb(user_desc, self.max_len)
        user_desc_emb = user_desc_emb.repeat(1 + self.num_ng, 1, 1)
        user_desc_mask = user_desc_mask.repeat(1 + self.num_ng, 1)
        user_tags_emb, user_tags_mask = self.get_emb(user_tags, 5)
        user_tags_emb = user_tags_emb.repeat(1 + self.num_ng, 1, 1)
        user_tags_mask = user_tags_mask.repeat(1 + self.num_ng, 1)
        item_desc_emb, item_desc_mask = self.get_emb(item_desc, self.max_len)#.view(1, -1)
        item_tags_emb, item_tags_mask = self.get_emb(item_tags, 5)#.view(1, -1)

        label = [1]

        num = 0
        while True:
            t_item_name = random.sample(self.itemid_set, 1)[0]
            item_line = self.item.loc[self.item["APIName"] == t_item_name]
            item_desc = item_line['desc']
            item_tags = item_line['tags']
            tmp_item_desc_emb, tmp_item_desc_mask = self.get_emb(item_desc, self.max_len)
            tmp_item_tags_emb, tmp_item_tags_mask = self.get_emb(item_tags, 5)

            item_desc_emb = torch.cat([item_desc_emb, tmp_item_desc_emb], 0)
            item_tags_emb = torch.cat([item_tags_emb, tmp_item_tags_emb], 0)

            item_desc_mask = torch.cat([item_desc_mask, tmp_item_desc_mask], 0)
            item_tags_mask = torch.cat([item_tags_mask, tmp_item_tags_mask], 0)

            label.append(0)
            num = num + 1
            if num == self.num_ng:
                break
        return user_desc_emb, user_desc_mask, user_tags_emb, user_tags_mask, item_desc_emb, item_desc_mask, item_tags_emb, item_tags_mask, np.array(label)

class w2v_data():
    def __init__(self, num_ng, max_len, batch_size, emb_dim, vocab_file, num_workers = 2):
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.num_ng = num_ng
        self.max_len = max_len
        self.emb_dim = emb_dim
        self.vocab_file = vocab_file

        

    def load_data(self, item_path, user_path, rating_path, shuffle = False):
        dataset = GBLdataset(item_path, user_path, rating_path, self.num_ng, self.max_len, self.emb_dim, self.vocab_file)
        dataloader = DataLoader(dataset, 
                                batch_size = self.batch_size,
                                num_workers = self.num_workers, 
                                pin_memory = True, 
                                shuffle = shuffle)
        return dataloader

class test_w2v_data():
    def __init__(self, num_ng, max_len, batch_size, emb_dim, vocab_file, num_workers = 2):
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.num_ng = num_ng
        self.max_len = max_len
        self.emb_dim = emb_dim
        self.vocab_file = vocab_file

        

    def load_data(self, item_path, user_path, rating_path, shuffle = False):
        dataset = GBLdataset(item_path, user_path, rating_path, self.num_ng, self.max_len, self.emb_dim, self.vocab_file)
        data = pd.read_csv(rating_path)
        test_sampler = MashupSampler(data['MashupName'].values.tolist())
        dataloader = DataLoader(dataset,
                                num_workers = self.num_workers, 
                                pin_memory = True, 
                                batch_sampler=test_sampler)
        return dataloader